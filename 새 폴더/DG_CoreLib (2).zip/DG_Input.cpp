#include "DG_Input.h"

DG_GameInput g_KeyInput;

DWORD	DG_Input::Key(DWORD dwKey)
{
	return m_KeyState[dwKey];
}

KEYSTATE DG_Input::MouseCheck(DWORD dwKey)
{
	if (dwKey & 0x100)
	{
		int ButtonNum = 0;
		switch (dwKey)
		{
		case DIK_LBUTTON:
			ButtonNum = 0;
			break;
		case DIK_RBUTTON:
			ButtonNum = 1;
			break;
		case DIK_MBUTTON:
			ButtonNum = 2;
		}
		if (KEYDOWN(m_PrevMouseState.rgbButtons[ButtonNum]))
		{
			if (KEYDOWN(m_MouseState.rgbButtons[ButtonNum]))
			{
				return KEYSTATE::KEY_HOLD;
			}
			else
			{
				return KEYSTATE::KEY_UP;
			}
		}
		else
		{
			if (KEYDOWN(m_MouseState.rgbButtons[ButtonNum]))
			{
				return KEYSTATE::KEY_PUSH;
			}
			else
			{
				return KEYSTATE::KEY_FREE;
			}
		}
	}
}


KEYSTATE    DG_Input::KeyCheck(DWORD dwKey)
{
	
	if (m_PrevKeyState[dwKey]&0x80)
	{
		if (KEYDOWN(m_KeyState[dwKey]))
		{
			return KEYSTATE::KEY_HOLD;
		}
		else
		{
			return KEYSTATE::KEY_UP;
		}
	}
	else
	{
		if (KEYDOWN(m_KeyState[dwKey]))
		{
			return KEYSTATE::KEY_PUSH;
		}
		else
		{
			return KEYSTATE::KEY_FREE;
		}
	}
	//m_PrevKeyState[dwKey] = m_KeyState[dwKey];
}

POINT		DG_Input::MousePos()
{
	m_MousePos.x = m_MouseState.lX;
	m_MousePos.y = m_MouseState.lY;
	return m_MousePos;
}
bool DG_Input::Init()
{

	memset(&this->m_KeyState, 0, sizeof(BYTE) * 256);
	memset(&this->m_MouseState, 0, sizeof(DIMOUSESTATE));

	HRESULT hr;
	DirectInput8Create(g_hInstance,
		DIRECTINPUT_VERSION,
		IID_IDirectInput8,
		(void**)&m_pDi, NULL);
	//keyboard
	if (FAILED(hr = m_pDi->CreateDevice(GUID_SysKeyboard, &m_pKey, NULL)))
	{
		return false;
	}
	if (FAILED(hr = m_pKey->SetDataFormat(&c_dfDIKeyboard)))
	{
		return false;
	}
	if (FAILED(hr = m_pKey->SetCooperativeLevel(g_hWnd,DISCL_NONEXCLUSIVE|DISCL_FOREGROUND|DISCL_NOWINKEY)))
	{
		return false;
	}
	while (m_pKey->Acquire() == DIERR_INPUTLOST);
	//Mouse
	if (FAILED(hr = m_pDi->CreateDevice(GUID_SysMouse, &m_pMouse, NULL)))
	{
		return false;
	}
	if (FAILED(hr = m_pMouse->SetDataFormat(&c_dfDIMouse)))
	{
		return false;
	}
	if (FAILED(hr = m_pMouse->SetCooperativeLevel(g_hWnd, DISCL_NONEXCLUSIVE| DISCL_FOREGROUND | DISCL_NOWINKEY)))
	{
		return false;
	}
	while (m_pMouse->Acquire() == DIERR_INPUTLOST);

	GetCursorPos(&m_MousePos);
	ScreenToClient(g_hWnd, &m_MousePos);
	return true;
}
bool DG_Input::Frame()
{
	HRESULT hr;
	if (FAILED(hr = m_pKey->GetDeviceState(256, &m_KeyState)))
	{
		while (m_pKey->Acquire() == DIERR_INPUTLOST);
	}
	if (FAILED(hr = m_pMouse->GetDeviceState(sizeof(DIMOUSESTATE), &m_MouseState)))
	{
		while (m_pMouse->Acquire() == DIERR_INPUTLOST);
	}
//MousePos();
	GetCursorPos(&m_MousePos);
	ScreenToClient(g_hWnd, &m_MousePos);
	
	g_KeyInput.bFront = m_KeyState[DIK_W];
	g_KeyInput.bBack = m_KeyState[DIK_S];
	g_KeyInput.bLeft = m_KeyState[DIK_A];
	g_KeyInput.bRight = m_KeyState[DIK_D];
	g_KeyInput.bAttack = m_MouseState.rgbButtons[0];
	g_KeyInput.bJump = m_KeyState[DIK_SPACE] || m_MouseState.rgbButtons[1];
	g_KeyInput.bDebug = m_KeyState[DIK_0];
	g_KeyInput.bReLoad = m_KeyState[DIK_R];
	g_KeyInput.pMousePos = m_MousePos;

	return true;
}

bool DG_Input::PostFrame()
{
	memcpy(m_PrevKeyState, m_KeyState, sizeof(BYTE) * 256);
	memcpy(&m_PrevMouseState, &m_MouseState, sizeof(DIMOUSESTATE));
	return true;
}

bool DG_Input::Render()
{
	return true;
}
bool DG_Input::Release()
{
	m_pKey->Unacquire();
	m_pMouse->Unacquire();

	m_pKey->Release();
	m_pMouse->Release();
	m_pDi->Release();

	return true;
}

DG_Input::DG_Input()
{
	ZeroMemory(m_KeyState, sizeof(BYTE)*256);
	ZeroMemory(m_PrevKeyState, sizeof(BYTE)* 256);
	ZeroMemory(&m_MouseState, sizeof(DIMOUSESTATE));
	ZeroMemory(&m_PrevMouseState, sizeof(DIMOUSESTATE));
}


DG_Input::~DG_Input()
{
}
