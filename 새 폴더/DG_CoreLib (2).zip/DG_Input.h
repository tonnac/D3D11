#pragma once

#include "DG_Std.h"

#define KEYDOWN(x) (x) & 0x80 ? true : false
#define KEYUP(x) (x) & 0x80 ? false : true

#define DIK_LBUTTON 0x100
#define DIK_RBUTTON 0x101
#define DIK_MBUTTON 0x102

class DG_Input:public CSingleton<DG_Input>
{
public:
	friend class  CSingleton<DG_Input>;
public:
	LPDIRECTINPUT8					m_pDi;
	LPDIRECTINPUTDEVICE8		m_pKey;
	LPDIRECTINPUTDEVICE8		m_pMouse;

	BYTE												m_KeyState[256];
	BYTE												m_PrevKeyState[256];
	DIMOUSESTATE						m_MouseState;
	DIMOUSESTATE						m_PrevMouseState;
	POINT											m_MousePos;
public:
	DWORD	Key(DWORD dwkey);
	KEYSTATE    KeyCheck(DWORD dwkey);
	POINT		MousePos();
	KEYSTATE	MouseCheck(DWORD dwKey);

	bool	Init();
	bool	Frame();	
	bool PostFrame();
	bool	Render();
	bool	Release();
public:
	DG_Input();
	virtual ~DG_Input();
};

#define I_Input DG_Input::GetInstance()
